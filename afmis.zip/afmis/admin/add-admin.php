<?php
include '../includes/auth.php';
include '../includes/config.php';

if (isset($_POST['add'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $sql = "INSERT INTO admins (username, password) VALUES ('$username', '$password')";
  if ($conn->query($sql) === TRUE) {
    $msg = "New admin added successfully.";
  } else {
    $msg = "Error: " . $conn->error;
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Add Admin</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm px-4 py-3">
  <a class="navbar-brand text-success" href="dashboard.php">🌿 AFMIS</a>
</nav>

<div class="container mt-5 px-5">
  <h3 class="mb-4 fw-bold">Add New Admin</h3>
  <?php if (!empty($msg)) echo "<div class='alert alert-info'>$msg</div>"; ?>
  <form action="" method="POST">
    <div class="mb-3">
      <label>Username</label>
      <input type="text" name="username" class="form-control rounded-pill" required>
    </div>
    <div class="mb-3">
      <label>Password</label>
      <input type="text" name="password" class="form-control rounded-pill" required>
    </div>
    <button type="submit" name="add" class="btn btn-success rounded-pill px-4">Add Admin</button>
    <a href="dashboard.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
  </form>
</div>

</body>
</html>
