<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Admin Login</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-success">

<div class="card shadow-lg p-5 w-25 text-center">
  <h3 class="mb-4 fw-bold">🌿 AFMIS Login</h3>
  <form action="dashboard.php" method="POST">
    <div class="mb-3 text-start">
      <label class="form-label">Username</label>
      <input type="text" name="username" class="form-control rounded-pill" required>
    </div>
    <div class="mb-3 text-start">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control rounded-pill" required>
    </div>
    <button type="submit" class="btn btn-success w-100 mt-3 rounded-pill"><i class="fas fa-sign-in-alt"></i> Login</button>
  </form>
</div>

</body>
</html>
