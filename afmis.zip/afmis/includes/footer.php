<footer>
  <div class="container">
    <p class="mb-0">© <?php echo date("Y"); ?> AFMIS | All Rights Reserved</p>
  </div>
</footer>
