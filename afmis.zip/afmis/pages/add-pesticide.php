<?php
include '../includes/auth.php';
include '../includes/config.php';

// Fetch admin info
$username = $_SESSION['admin_username'];
$resultAdmin = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $resultAdmin ? $resultAdmin->fetch_assoc() : ['profile_picture' => 'default.png', 'username' => 'Admin'];

// Fetch crops list
$crops = $conn->query("SELECT id, crop_name FROM crops ORDER BY crop_name ASC");

// Fetch notifications
$notifications = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC");
$notificationCount = $notifications->num_rows;

// Handle form submission
if (isset($_POST['submit'])) {
  $crop_id = $conn->real_escape_string($_POST['crop_id']);
  $pesticide_name = $conn->real_escape_string($_POST['pesticide_name']);
  $application_date = $conn->real_escape_string($_POST['application_date']);
  $notes = $conn->real_escape_string($_POST['notes']);

  $sql = "INSERT INTO pesticides (crop_id, pesticide_name, application_date, notes)
          VALUES ('$crop_id', '$pesticide_name', '$application_date', '$notes')";

  if ($conn->query($sql) === TRUE) {
    $cropResult = $conn->query("SELECT crop_name FROM crops WHERE id='$crop_id'");
    $cropName = $cropResult->fetch_assoc()['crop_name'];
    $message = "$username applied pesticide '$pesticide_name' to $cropName crop.";
    $link = "view-pesticides.php";
    $conn->query("INSERT INTO notifications (message, link, created_at) VALUES ('$message', '$link', NOW())");

    header("Location: view-pesticides.php");
    exit();
  } else {
    $error = "Error: " . $conn->error;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Add Pesticide</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
  <style>
    body { display: flex; min-height: 100vh; font-family: 'Nunito', sans-serif; margin: 0; }
    .sidebar { width:230px; background:#198754; color:#fff; position:fixed; top:0; bottom:0; padding:20px 0; overflow-y:auto; transition:all 0.3s ease; z-index:999; }
    .sidebar a { display:block; color:#fff; padding:12px 20px; text-decoration:none; font-weight:600; }
    .sidebar a:hover, .sidebar .dropdown-menu a:hover { background:#157347; }
    .sidebar .dropdown-menu { background:#198754; }
    .sidebar .dropdown-menu a { color:#fff; }
    .content { flex:1; padding:30px; margin-left:230px; display:flex; flex-direction:column; transition: all 0.3s ease; }
    .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
    .profile-pic { width:40px; height:40px; border-radius:50%; object-fit:cover; }
    .notification .badge { font-size:0.7rem; }
    footer { background:#f8f9fa; text-align:center; padding:10px 0; border-top:1px solid #ddd; margin-top:auto; font-size:14px; }
    .overlay { display:none; position:fixed; top:0; left:0; z-index:998; width:100%; height:100%; background:rgba(0,0,0,0.5); }
    @media(max-width:991.98px) {
      .sidebar { left:-250px; position:fixed; }
      .sidebar.show { left:0; }
      .content { margin-left:0; padding:20px; }
      .overlay.active { display:block; }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebarMenu">
  <h4 class="text-center">🌿 AFMIS</h4>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
  <a href="view-crops.php"><i class="fa fa-seedling me-2"></i> Crops</a>
  <a href="manage-livestock.php"><i class="fa fa-cow me-2"></i> Livestock</a>
  <a href="view-pesticides.php" class="bg-success"><i class="fa fa-bug me-2"></i> Pesticides</a>
  <a href="view-activities.php"><i class="fa fa-tractor me-2"></i> Activities</a>
  <div class="dropdown">
    <a href="#" class="dropdown-toggle px-3 d-block" data-bs-toggle="dropdown">
      <i class="fa fa-heartbeat me-2"></i> Mortality Rate
    </a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="birth-rate.php"><i class="fa fa-plus me-2"></i> Birth Rate</a></li>
      <li><a class="dropdown-item" href="death-rate.php"><i class="fa fa-minus me-2"></i> Death Rate</a></li>
    </ul>
  </div>
  <a href="eggs-production.php"><i class="fa fa-egg me-2"></i> Eggs Production</a>
  <a href="sales.php"><i class="fa fa-cart-plus me-2"></i> Sales</a>
  <a href="view-sales.php"><i class="fa fa-file-invoice-dollar me-2"></i> View Sales</a>
  <a href="generate-report.php"><i class="fa fa-file-alt me-2"></i> Generate Report</a>
  <a href="request-item.php"><i class="fa fa-hand-holding-medical me-2"></i> Request Item</a>
  <a href="view-requests.php"><i class="fa fa-list me-2"></i> View Requests</a>
</div>

<div class="overlay" id="sidebarOverlay"></div>

<div class="content">

  <div class="topbar">
    <button class="btn btn-success d-lg-none" id="toggleSidebar"><i class="fa fa-bars"></i></button>
    <div class="d-flex align-items-center">
      <div class="dropdown me-3">
        <a href="#" class="text-dark text-decoration-none position-relative" data-bs-toggle="dropdown">
          <i class="fa fa-bell fs-5"></i>
          <?php if($notificationCount > 0): ?>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
            <?= $notificationCount ?>
          </span>
          <?php endif; ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <?php if($notificationCount==0): ?>
            <li><span class="dropdown-item text-muted">No new notifications</span></li>
          <?php else: while($notif=$notifications->fetch_assoc()): ?>
            <li><a class="dropdown-item" href="<?= $notif['link'] ?>"><?= $notif['message'] ?></a></li>
          <?php endwhile; endif; ?>
        </ul>
      </div>
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
          <img src="../uploads/<?= $admin['profile_picture'] ?>" class="profile-pic me-2">
          <?= htmlspecialchars($admin['username']) ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="profile.php">Manage Profile</a></li>
          <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>

  <h3 class="mb-4 fw-bold">Add New Pesticide Application</h3>

  <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

  <form action="" method="POST" class="row g-3 mb-5">
    <div class="col-md-6">
      <label class="form-label fw-semibold">Select Crop</label>
      <select name="crop_id" class="form-select rounded-pill" required>
        <option value="">-- Select Crop --</option>
        <?php while($crop = $crops->fetch_assoc()): ?>
          <option value="<?= $crop['id'] ?>"><?= htmlspecialchars($crop['crop_name']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-6">
      <label class="form-label fw-semibold">Pesticide Name</label>
      <input type="text" name="pesticide_name" class="form-control rounded-pill" required>
    </div>
    <div class="col-md-6">
      <label class="form-label fw-semibold">Application Date</label>
      <input type="date" name="application_date" class="form-control rounded-pill" required>
    </div>
    <div class="col-12">
      <label class="form-label fw-semibold">Notes</label>
      <textarea name="notes" class="form-control" rows="3"></textarea>
    </div>
    <div class="col-12">
      <button type="submit" name="submit" class="btn btn-success rounded-pill px-4"><i class="fas fa-save"></i> Save Application</button>
      <a href="view-pesticides.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
    </div>
  </form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const sidebar = document.getElementById('sidebarMenu');
  const overlay = document.getElementById('sidebarOverlay');
  const toggleBtn = document.getElementById('toggleSidebar');

  toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('show');
    overlay.classList.toggle('active');
  });

  overlay.addEventListener('click', () => {
    sidebar.classList.remove('show');
    overlay.classList.remove('active');
  });
</script>
</body>
</html>
