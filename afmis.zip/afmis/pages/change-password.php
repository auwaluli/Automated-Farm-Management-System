<?php
include '../includes/auth.php';
include '../includes/config.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $admin = $conn->query("SELECT * FROM admins WHERE id='$id'")->fetch_assoc();

  if (!$admin) {
    echo "Admin not found.";
    exit();
  }
} else {
  header("Location: manage-admins.php");
  exit();
}

if (isset($_POST['update'])) {
  $new_password = $_POST['password'];
  $conn->query("UPDATE admins SET password='$new_password' WHERE id='$id'");
  header("Location: manage-admins.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Change Password | AFMIS</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="p-5">
  <h3>Change Password for <?php echo htmlspecialchars($admin['username']); ?></h3>
  <form method="POST" class="mt-3">
    <div class="mb-3">
      <label>New Password</label>
      <input type="text" name="password" class="form-control" required>
    </div>
    <button type="submit" name="update" class="btn btn-primary">Update Password</button>
    <a href="manage-admins.php" class="btn btn-secondary">Cancel</a>
  </form>
</body>
</html>
