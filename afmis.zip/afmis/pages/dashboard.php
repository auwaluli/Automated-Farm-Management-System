<?php
include '../includes/auth.php';
include '../includes/config.php';

// Function to safely fetch a count from a table
function getCount($conn, $table, $column = 'id') {
  $result = $conn->query("SELECT COUNT($column) AS total FROM $table");
  return $result ? $result->fetch_assoc()['total'] : 0;
}

// Function to safely fetch a sum from a table column
function getSum($conn, $table) {
  $result = $conn->query("SELECT SUM(quantity) AS total FROM $table");
  $data = $result ? $result->fetch_assoc()['total'] : 0;
  return $data ?: 0;
}

// Fetch totals
$cropsCount       = getCount($conn, 'crops');
$pesticidesCount  = getCount($conn, 'pesticides');
$activitiesCount  = getCount($conn, 'activities');
$adminsCount      = getCount($conn, 'admins');
$birthCount       = getSum($conn, 'births');
$deathCount       = getSum($conn, 'deaths');
$livestockAdded   = getSum($conn, 'livestock');

// Total livestock
$totalLivestock   = $livestockAdded + $birthCount - $deathCount;
if ($totalLivestock < 0) $totalLivestock = 0;

// Eggs production today
$todayEggs = $conn->query("SELECT SUM(quantity) AS total FROM eggs WHERE date = CURDATE()")->fetch_assoc()['total'] ?? 0;

// Eggs this month
$monthEggs = $conn->query("SELECT SUM(quantity) AS total FROM eggs WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())")->fetch_assoc()['total'] ?? 0;

// Net Sales Today
$netSalesToday = $conn->query("SELECT SUM(total_amount) AS total FROM sales WHERE sale_date = CURDATE()")->fetch_assoc()['total'] ?? 0;

// Net Sales This Month
$netSalesMonth = $conn->query("SELECT SUM(total_amount) AS total FROM sales WHERE MONTH(sale_date) = MONTH(CURDATE()) AND YEAR(sale_date) = YEAR(CURDATE())")->fetch_assoc()['total'] ?? 0;

// Total available stock (from items table)
$totalStock = $conn->query("SELECT SUM(stock) AS total FROM items")->fetch_assoc()['total'] ?? 0;

// Fetch admin profile
$username = $_SESSION['admin_username'];
$result = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $result ? $result->fetch_assoc() : ['profile_picture' => 'default.png', 'username' => 'Admin'];

// Fetch unread notifications
$notifications = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC");
$notificationCount = $notifications->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
  <style>
body {
  margin: 0;
  font-family: 'Nunito', sans-serif;
}
.wrapper {
  display: flex;
  min-height: 100vh;
}
.sidebar {
  width: 230px;
  background: #198754;
  color: #fff;
  padding: 20px 0;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  transition: all 0.3s ease;
}
.sidebar a {
  display: block;
  color: #fff;
  padding: 12px 20px;
  text-decoration: none;
  font-weight: 600;
}
.sidebar a:hover {
  background: #157347;
}
.content {
  flex: 1;
  padding: 30px;
}
.card {
  border-radius: 18px;
  transition: all 0.3s ease;
}
.card:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 18px rgba(0,0,0,0.08);
}
.topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 20px;
}
.profile-pic {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
}
footer {
  background: #f8f9fa;
  text-align: center;
  padding: 12px 0;
  border-top: 1px solid #ddd;
  font-size: 14px;
}
@media (max-width: 991.98px) {
  .sidebar {
    position: fixed;
    top: 0;
    bottom: 0;
    left: -250px;
    z-index: 999;
    overflow-y: auto;
  }
  .sidebar.show {
    left: 0;
  }
  .overlay {
    display: none;
  }
  .overlay.active {
    display: block;
    position: fixed;
    top: 0; left: 0;
    z-index: 998;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
  }
}
  </style>
</head>
<body>

<div class="wrapper">

  <!-- Sidebar -->
  <div class="sidebar" id="sidebarMenu">
    <h4 class="text-center">🌿 AFMIS</h4>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
    <a href="view-crops.php"><i class="fa fa-seedling me-2"></i> Crops</a>
    <a href="manage-livestock.php"><i class="fa fa-cow me-2"></i> Livestock</a>
    <a href="view-pesticides.php"><i class="fa fa-bug me-2"></i> Pesticides</a>
    <a href="view-activities.php"><i class="fa fa-tractor me-2"></i> Activities</a>
    <a href="birth-rate.php"><i class="fa fa-plus me-2"></i> Birth Rate</a>
    <a href="death-rate.php"><i class="fa fa-minus me-2"></i> Death Rate</a>
    <a href="eggs-production.php"><i class="fa fa-egg me-2"></i> Eggs Production</a>
    <a href="sales.php"><i class="fa fa-cart-plus me-2"></i> Sales</a>
    <a href="view-sales.php"><i class="fa fa-file-invoice-dollar me-2"></i> View Sales</a>
    <a href="generate-report.php"><i class="fa fa-file-alt me-2"></i> Generate Report</a>
    <a href="request-item.php"><i class="fa fa-box-open me-2"></i> Request Item</a>
    <a href="view-requests.php"><i class="fa fa-eye me-2"></i> View Requests</a>
  </div>

  <!-- Overlay -->
  <div class="overlay" id="sidebarOverlay"></div>

  <!-- Content -->
  <div class="content">

   <div class="topbar">
  <button class="btn btn-outline-dark d-lg-none me-3" id="toggleSidebar">
    <i class="fa fa-bars"></i>
  </button>

  <div class="d-flex align-items-center">

    <!-- Notifications -->
    <div class="dropdown me-3">
      <a href="#" class="text-dark text-decoration-none position-relative" data-bs-toggle="dropdown">
        <i class="fa fa-bell fs-5"></i>
        <?php if($notificationCount > 0): ?>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
          <?= $notificationCount ?>
        </span>
        <?php endif; ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php if($notificationCount == 0): ?>
        <li><span class="dropdown-item text-muted">No new notifications</span></li>
        <?php else: while($notif = $notifications->fetch_assoc()): ?>
        <li><a class="dropdown-item" href="<?= $notif['link'] ?>"><?= $notif['message'] ?></a></li>
        <?php endwhile; endif; ?>
      </ul>
    </div>

    <!-- Profile dropdown -->
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
        <img src="../uploads/<?php echo $admin['profile_picture']; ?>" class="profile-pic me-2">
        <?php echo htmlspecialchars($admin['username']); ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="profile.php">Manage Profile</a></li>
        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>

  </div>
</div>


    <h3 class="fw-bold mb-4">Dashboard Overview</h3>

    <div class="row g-4">
      <?php
      $cards = [
        ['title' => 'Net Sales Today', 'icon' => 'fa-money-bill-wave text-info', 'value' => '₦' . number_format($netSalesToday)],
        ['title' => 'Sales This Month', 'icon' => 'fa-coins text-info', 'value' => '₦' . number_format($netSalesMonth)],
        ['title' => 'Total Stock', 'icon' => 'fa-boxes text-success', 'value' => $totalStock],
        ['title' => 'Crops', 'icon' => 'fa-seedling text-success', 'value' => $cropsCount],
        ['title' => 'Livestock', 'icon' => 'fa-cow text-success', 'value' => $totalLivestock],
        ['title' => 'Pesticides', 'icon' => 'fa-bug text-success', 'value' => $pesticidesCount],
        ['title' => 'Activities', 'icon' => 'fa-tractor text-success', 'value' => $activitiesCount],
        ['title' => 'Admins', 'icon' => 'fa-user-shield text-success', 'value' => $adminsCount],
        ['title' => 'Total Births', 'icon' => 'fa-plus text-primary', 'value' => $birthCount],
        ['title' => 'Total Deaths', 'icon' => 'fa-minus text-danger', 'value' => $deathCount],
        ['title' => 'Eggs Today', 'icon' => 'fa-egg text-warning', 'value' => $todayEggs],
        ['title' => 'Eggs This Month', 'icon' => 'fa-calendar text-primary', 'value' => $monthEggs],
      ];
      foreach ($cards as $card) {
        echo '
        <div class="col-12 col-md-3">
          <div class="card text-center p-4 shadow-sm">
            <i class="fa '.$card['icon'].' fa-3x mb-3"></i>
            <h5>'.$card['title'].'</h5>
            <h2>'.$card['value'].'</h2>
          </div>
        </div>';
      }
      ?>
    </div>

    <footer class="mt-4">
      <small>© <?php echo date('Y'); ?> AFMIS | Developed by Auwal Uli</small>
    </footer>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const sidebar = document.querySelector('.sidebar');
const overlay = document.getElementById('sidebarOverlay');
const toggleBtn = document.getElementById('toggleSidebar');

toggleBtn.addEventListener('click', () => {
  sidebar.classList.toggle('show');
  overlay.classList.toggle('active');
});
overlay.addEventListener('click', () => {
  sidebar.classList.remove('show');
  overlay.classList.remove('active');
});
</script>

</body>
</html>
