<?php
include '../includes/auth.php';
include '../includes/config.php';

if (isset($_GET['id'])) {
  $id = (int)$_GET['id'];

  // Delete the request
  $conn->query("DELETE FROM requests WHERE id=$id");

  // Optionally: also remove related notifications
  $conn->query("DELETE FROM notifications WHERE link='view-requests.php'");

  // Redirect back
  header("Location: view-requests.php");
  exit();
} else {
  header("Location: view-requests.php");
  exit();
}
?>
