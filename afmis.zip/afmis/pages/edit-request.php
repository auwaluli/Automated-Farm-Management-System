<?php
include '../includes/auth.php';
include '../includes/config.php';

if (!isset($_GET['id'])) {
  header("Location: view-requests.php");
  exit();
}

$id = (int)$_GET['id'];

// Fetch request details
$request = $conn->query("SELECT * FROM requests WHERE id=$id")->fetch_assoc();
if (!$request) {
  header("Location: view-requests.php");
  exit();
}

// Fetch admin profile
$username = $_SESSION['admin_username'];
$resultAdmin = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $resultAdmin ? $resultAdmin->fetch_assoc() : ['profile_picture' => 'default.png', 'username' => 'Admin'];

// Fetch notifications
$notifications = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC");
$notificationCount = $notifications->num_rows;

// Handle update
if (isset($_POST['update_request'])) {
  $item = $conn->real_escape_string($_POST['item']);
  $description = $conn->real_escape_string($_POST['description']);
  $quantity = (int)$_POST['quantity'];

  $conn->query("UPDATE requests SET item_name='$item', description='$description', quantity=$quantity WHERE id=$id");
  $success = "Request updated successfully!";
  header("Refresh:2; url=view-requests.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Edit Request</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    body { display: flex; min-height: 100vh; font-family: 'Nunito', sans-serif; margin: 0; }
    .sidebar { width: 230px; background: #198754; color: #fff; position: fixed; top: 0; bottom: 0; padding: 20px 0; }
    .sidebar a { display: block; color: #fff; padding: 12px 20px; text-decoration: none; font-weight: 600; }
    .sidebar a:hover, .sidebar .dropdown-menu a:hover { background: #157347; }
    .content { margin-left: 230px; padding: 30px; flex: 1; }
    .topbar { display: flex; justify-content: flex-end; align-items: center; padding: 12px 0; margin-bottom: 20px; }
    .profile-pic { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
    .badge { font-size: 0.7rem; }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h4 class="text-center">🌿 AFMIS</h4>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
  <a href="view-crops.php"><i class="fa fa-seedling me-2"></i> Crops</a>
  <a href="manage-livestock.php"><i class="fa fa-cow me-2"></i> Livestock</a>
  <a href="view-pesticides.php"><i class="fa fa-bug me-2"></i> Pesticides</a>
  <a href="view-activities.php"><i class="fa fa-tractor me-2"></i> Activities</a>
  <div class="dropdown">
    <a href="#" class="dropdown-toggle px-3 d-block" data-bs-toggle="dropdown">
      <i class="fa fa-heartbeat me-2"></i> Mortality Rate
    </a>
    <ul class="dropdown-menu bg-success">
      <li><a class="dropdown-item text-white" href="birth-rate.php"><i class="fa fa-plus me-2"></i> Birth Rate</a></li>
      <li><a class="dropdown-item text-white" href="death-rate.php"><i class="fa fa-minus me-2"></i> Death Rate</a></li>
    </ul>
  </div>
  <a href="eggs-production.php"><i class="fa fa-egg me-2"></i> Eggs Production</a>
  <a href="sales.php"><i class="fa fa-cart-plus me-2"></i> Sales</a>
  <a href="view-sales.php"><i class="fa fa-file-invoice-dollar me-2"></i> View Sales</a>
  <a href="generate-report.php"><i class="fa fa-file-alt me-2"></i> Generate Report</a>
  <a href="request-item.php"><i class="fa fa-hand-holding-medical me-2"></i> Request Item</a>
  <a href="view-requests.php"><i class="fa fa-list me-2"></i> View Requests</a>
</div>

<!-- Content -->
<div class="content">

  <!-- Topbar -->
  <div class="topbar">
    <div class="dropdown me-3">
      <a href="#" class="text-dark text-decoration-none position-relative" data-bs-toggle="dropdown">
        <i class="fa fa-bell fs-5"></i>
        <?php if($notificationCount > 0): ?>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
            <?= $notificationCount ?>
          </span>
        <?php endif; ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php if($notificationCount == 0): ?>
          <li><span class="dropdown-item text-muted">No new notifications</span></li>
        <?php else: while($notif = $notifications->fetch_assoc()): ?>
          <li><a class="dropdown-item" href="<?= $notif['link'] ?>"><?= $notif['message'] ?></a></li>
        <?php endwhile; endif; ?>
      </ul>
    </div>
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
        <img src="../uploads/<?php echo $admin['profile_picture']; ?>" class="profile-pic me-2">
        <?php echo htmlspecialchars($admin['username']); ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="profile.php">Manage Profile</a></li>
        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>

  <h3 class="fw-bold mb-4">Edit Item Request</h3>

  <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>

  <div class="card shadow-sm">
    <div class="card-header bg-success text-white fw-bold">Edit Request</div>
    <div class="card-body">
      <form method="POST">
        <div class="mb-3">
          <label>Item Name</label>
          <input type="text" name="item" class="form-control" value="<?= htmlspecialchars($request['item_name']) ?>" required>
        </div>
        <div class="mb-3">
          <label>Description</label>
          <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($request['description']) ?></textarea>
        </div>
        <div class="mb-3">
          <label>Quantity</label>
          <input type="number" name="quantity" class="form-control" value="<?= $request['quantity'] ?>" required>
        </div>
        <button type="submit" name="update_request" class="btn btn-success">Update Request</button>
        <a href="view-requests.php" class="btn btn-secondary">Cancel</a>
      </form>
    </div>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
