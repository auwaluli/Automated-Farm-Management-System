<?php
include '../includes/auth.php';
include '../includes/config.php';

// Check if transaction ID is passed
if (!isset($_GET['transaction_id'])) {
    die("No transaction selected.");
}

$transaction_id = $conn->real_escape_string($_GET['transaction_id']);

// Fetch sales records for transaction
$sales = $conn->query("SELECT * FROM sales WHERE transaction_id = '$transaction_id' ORDER BY sale_date ASC");

if (!$sales || $sales->num_rows == 0) {
    die("No records found for this transaction.");
}

// Fetch first record for sale date
$firstSale = $sales->fetch_assoc();
$sales->data_seek(0); // Reset pointer for looping

// Fetch seller/admin details
$username = $_SESSION['admin_username'];
$result = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $result ? $result->fetch_assoc() : ['username' => 'Admin'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>AFMIS | Print Receipt</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { font-family: 'Nunito', sans-serif; margin: 20px; }
        .receipt-box {
            max-width: 700px;
            margin: auto;
            padding: 30px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h3 { text-align: center; margin-bottom: 10px; }
        .company-details { text-align: center; font-size: 14px; margin-bottom: 20px; }
        .line { border-top: 1px dashed #ccc; margin: 15px 0; }
        table { width: 100%; }
        th, td { padding: 6px 8px; text-align: left; font-size: 14px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>

<div class="receipt-box">
    <h3>🌿 AFMIS FARM SALE RECEIPT</h3>
    <div class="company-details">
        <strong>AFMIS Integrated Farms</strong><br>
        Office: No. 123 Farmland Avenue, Katsina State, Nigeria<br>
        Phone: +234 816 476 4758, +234 902 666 2966<br>
        Email: auwalyuli12@gmail.com
    </div>

    <div class="line"></div>

    <p><strong>Transaction ID:</strong> <?php echo htmlspecialchars($transaction_id); ?></p>
    <p><strong>Sale Date & Time:</strong>
        <?php
        if (!empty($firstSale['sale_date']) && strtotime($firstSale['sale_date']) !== false) {
            echo date("d M Y h:i A", strtotime($firstSale['sale_date']));
        } else {
            echo "Not recorded";
        }
        ?>
    </p>
    <p><strong>Sold By:</strong> <?php echo htmlspecialchars($admin['username']); ?></p>

    <div class="line"></div>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Item Type</th>
                <th>Animal/Item</th>
                <th>Qty</th>
                <th>Unit Price (₦)</th>
                <th>Total (₦)</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            $grandTotal = 0;
            while ($row = $sales->fetch_assoc()) {
                $grandTotal += $row['total_amount'];
                ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($row['item_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['animal_type']); ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo number_format($row['price'], 2); ?></td>
                    <td><?php echo number_format($row['total_amount'], 2); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="line"></div>

    <p class="text-end fw-bold fs-5">Grand Total: ₦<?php echo number_format($grandTotal, 2); ?></p>

    <p class="text-center mt-3">Thank you for your patronage!</p>

    <div class="text-center no-print mt-3">
        <button onclick="window.print()" class="btn btn-primary">🖨️ Print Receipt</button>
        <a href="view-sales.php" class="btn btn-secondary">⬅️ Back to Sales</a>
    </div>
</div>

</body>
</html>
