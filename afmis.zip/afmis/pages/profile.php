<?php
include '../includes/auth.php';
include '../includes/config.php';

$username = $_SESSION['admin_username'];
$result = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $result->fetch_assoc() ?? ['profile_picture' => 'default.png', 'username' => 'Admin'];

// Handle profile picture update
if (isset($_POST['update_pic'])) {
  $file = $_FILES['profile_picture'];
  if ($file['error'] === 0) {
    $filename = time() . '_' . basename($file['name']);
    move_uploaded_file($file['tmp_name'], "../uploads/$filename");
    $conn->query("UPDATE admins SET profile_picture='$filename' WHERE username='$username'");
    header("Location: profile.php");
    exit();
  }
}

// Handle password update
if (isset($_POST['update_pass'])) {
  $current_password = $_POST['current_password'];
  $new_password = $_POST['new_password'];
  if ($current_password === $admin['password']) {
    $conn->query("UPDATE admins SET password='$new_password' WHERE username='$username'");
    $msg = "<div class='alert alert-success'>Password updated successfully.</div>";
  } else {
    $msg = "<div class='alert alert-danger'>Incorrect current password.</div>";
  }
}

// Notifications
$notifications = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC");
$notificationCount = $notifications->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Nunito', sans-serif;
      margin: 0;
      overflow-x: hidden;
    }
    .sidebar {
      width: 230px;
      background: #198754;
      color: #fff;
      position: fixed;
      top: 0; left: 0;
      bottom: 0;
      padding: 20px 0;
      overflow-y: auto;
      z-index: 1000;
      transition: left 0.3s ease;
    }
    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      font-weight: 600;
    }
    .sidebar a:hover, .sidebar .dropdown-menu a:hover {
      background: #157347;
    }
    .sidebar .dropdown-menu {
      background: #198754;
    }
    .sidebar .dropdown-menu a {
      color: #fff;
    }
    .topbar {
      position: fixed;
      left: 230px;
      right: 0;
      top: 0;
      height: 60px;
      background: #f8f9fa;
      border-bottom: 1px solid #ddd;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      z-index: 999;
      transition: left 0.3s ease;
    }
    .profile-pic {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #198754;
    }
    .content {
      margin-left: 230px;
      padding: 80px 20px 20px;
      transition: margin-left 0.3s ease;
    }
    /* Mobile behavior */
    @media (max-width: 991.98px) {
      .sidebar {
        left: -230px;
      }
      .sidebar.active {
        left: 0;
      }
      .topbar {
        left: 0;
      }
      .content {
        margin-left: 0;
      }
      .overlay {
        display: none;
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 998;
      }
      .overlay.active {
        display: block;
      }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebarMenu">
  <h4 class="text-center">🌿 AFMIS</h4>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
  <a href="view-crops.php"><i class="fa fa-seedling me-2"></i> Crops</a>
  <a href="manage-livestock.php"><i class="fa fa-cow me-2"></i> Livestock</a>
  <a href="view-pesticides.php"><i class="fa fa-bug me-2"></i> Pesticides</a>
  <a href="view-activities.php"><i class="fa fa-tractor me-2"></i> Activities</a>
  <div class="dropdown">
    <a href="#" class="dropdown-toggle px-3 d-block" data-bs-toggle="dropdown">
      <i class="fa fa-heartbeat me-2"></i> Mortality Rate
    </a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="birth-rate.php"><i class="fa fa-plus me-2"></i> Birth Rate</a></li>
      <li><a class="dropdown-item" href="death-rate.php"><i class="fa fa-minus me-2"></i> Death Rate</a></li>
    </ul>
  </div>
  <a href="eggs-production.php"><i class="fa fa-egg me-2"></i> Eggs Production</a>
  <a href="sales.php"><i class="fa fa-cart-plus me-2"></i> Sales</a>
  <a href="view-sales.php"><i class="fa fa-file-invoice-dollar me-2"></i> View Sales</a>
  <a href="generate-report.php"><i class="fa fa-file-alt me-2"></i> Generate Report</a>
  <a href="request-item.php"><i class="fa fa-hand-holding-medical me-2"></i> Request Item</a>
  <a href="view-requests.php"><i class="fa fa-list me-2"></i> View Requests</a>
</div>
</div>

<div class="topbar">
  <button class="btn btn-success d-lg-none" id="toggleSidebar"><i class="fa fa-bars"></i></button>
  <div class="d-flex align-items-center">
    <div class="dropdown me-3">
      <a href="#" class="text-dark text-decoration-none position-relative" data-bs-toggle="dropdown">
        <i class="fa fa-bell fs-5"></i>
        <?php if($notificationCount>0): ?>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?= $notificationCount ?></span>
        <?php endif; ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php if($notificationCount==0): ?>
          <li><span class="dropdown-item text-muted">No new notifications</span></li>
        <?php else: while($notif=$notifications->fetch_assoc()): ?>
          <li><a class="dropdown-item" href="<?= htmlspecialchars($notif['link']) ?>"><?= htmlspecialchars($notif['message']) ?></a></li>
        <?php endwhile; endif; ?>
      </ul>
    </div>
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
        <img src="../uploads/<?= htmlspecialchars($admin['profile_picture']) ?>" class="rounded-circle me-2" width="40" height="40">
        <?= htmlspecialchars($admin['username']) ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="profile.php">Manage Profile</a></li>
        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</div>

<div class="content">
  <h3 class="fw-bold mb-4">Manage Profile</h3>
  <?php if (isset($msg)) echo $msg; ?>
  <div class="mb-4 text-center">
    <img src="../uploads/<?= htmlspecialchars($admin['profile_picture']) ?>" class="profile-pic mb-2">
    <h5 class="mt-2"><?= htmlspecialchars($admin['username']) ?></h5>
  </div>

  <form method="POST" enctype="multipart/form-data" class="mb-5">
    <h5>Change Profile Picture</h5>
    <div class="mb-3">
      <input type="file" name="profile_picture" class="form-control" required>
    </div>
    <button type="submit" name="update_pic" class="btn btn-success">Update Picture</button>
  </form>

  <form method="POST">
    <h5>Change Password</h5>
    <div class="mb-3">
      <label>Current Password</label>
      <input type="password" name="current_password" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>New Password</label>
      <input type="password" name="new_password" class="form-control" required>
    </div>
    <button type="submit" name="update_pass" class="btn btn-success">Update Password</button>
  </form>
</div>

<div class="overlay" id="sidebarOverlay"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const sidebar = document.getElementById('sidebarMenu');
const overlay = document.getElementById('sidebarOverlay');
document.getElementById('toggleSidebar').addEventListener('click', () => {
  sidebar.classList.toggle('active');
  overlay.classList.toggle('active');
});
overlay.addEventListener('click', () => {
  sidebar.classList.remove('active');
  overlay.classList.remove('active');
});
</script>
</body>
</html>
