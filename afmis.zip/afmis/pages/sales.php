<?php
include '../includes/auth.php';
include '../includes/config.php';

$username = $_SESSION['admin_username'];
$resultAdmin = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $resultAdmin ? $resultAdmin->fetch_assoc() : ['profile_picture' => 'default.png', 'username' => 'Admin'];

$notifications = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC");
$notificationCount = $notifications->num_rows;

$availableItems = ['Cattle','Goats','Sheep','Chickens','Ducks','Turkeys','Rabbits','Fish (Catfish)','Fish (Tilapia)','Camels','Eggs'];

if (isset($_POST['add_item'])) {
  $item_name = $conn->real_escape_string($_POST['item_name']);
  $price = (int)$_POST['price'];
  $stock = (int)$_POST['stock'];

  $check = $conn->query("SELECT * FROM items WHERE item_name='$item_name'");
  if ($check->num_rows > 0) {
    $conn->query("UPDATE items SET stock = stock + $stock, price = $price WHERE item_name='$item_name'");
    $msg = "<div class='alert alert-success'>Item stock updated successfully.</div>";
  } else {
    $conn->query("INSERT INTO items (item_name, price, stock) VALUES ('$item_name', $price, $stock)");
    $msg = "<div class='alert alert-success'>New item added successfully.</div>";
  }
}

if (isset($_POST['make_sale'])) {
  $items = $_POST['sale_item'];
  $quantities = $_POST['quantity'];
  $transaction_id = uniqid('TXN_');

  foreach ($items as $index => $item_name) {
    $item_name = $conn->real_escape_string($item_name);
    $quantity = (int)$quantities[$index];
    $item = $conn->query("SELECT * FROM items WHERE item_name='$item_name'")->fetch_assoc();

    if ($item && $item['stock'] >= $quantity) {
      $price = $item['price'];
      $total_amount = $price * $quantity;
      $item_type = ($item_name == 'Eggs') ? 'Eggs' : 'Livestock';

      $conn->query("INSERT INTO sales (transaction_id, item_name, item_type, animal_type, quantity, price, total_amount, sale_date)
        VALUES ('$transaction_id', '$item_name', '$item_type', '$item_name', $quantity, $price, $total_amount, NOW())");

      $conn->query("UPDATE items SET stock = stock - $quantity WHERE item_name='$item_name'");
      $saleSuccess[] = "$quantity $item_name";
    } else {
      $saleErrors[] = $item_name;
    }
  }

  if (!empty($saleSuccess)) $msg = "<div class='alert alert-success'>Sold: ".implode(", ",$saleSuccess)." under Transaction ID: $transaction_id</div>";
  if (!empty($saleErrors)) $msg .= "<div class='alert alert-danger'>Insufficient stock for: ".implode(", ",$saleErrors).".</div>";
}

$stockList = $conn->query("SELECT * FROM items ORDER BY item_name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | Stock & Sales</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
  <style>
    body { display:flex; min-height:100vh; font-family:'Nunito',sans-serif; margin:0; }
    .sidebar { width:230px; background:#198754; color:#fff; position:fixed; top:0; bottom:0; padding:20px 0; overflow-y:auto; transition:all 0.3s ease; z-index:999; }
    .sidebar a { display:block; color:#fff; padding:12px 20px; text-decoration:none; font-weight:600; }
    .sidebar a:hover,.sidebar .dropdown-menu a:hover { background:#157347; }
    .content { flex:1; padding:30px; margin-left:230px; display:flex; flex-direction:column; transition:all 0.3s ease; }
    .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
    .profile-pic { width:40px; height:40px; border-radius:50%; object-fit:cover; }
    .overlay { display:none; position:fixed; top:0; left:0; z-index:998; width:100%; height:100%; background:rgba(0,0,0,0.5); }
    @media(max-width:991.98px){
      .sidebar{left:-250px;}
      .sidebar.show{left:0;}
      .content{margin-left:0; padding:20px;}
      .overlay.active{display:block;}
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebarMenu">
  <h4 class="text-center">🌾 AFMIS</h4>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
  <a href="view-crops.php"><i class="fa fa-seedling me-2"></i> Crops</a>
  <a href="manage-livestock.php"><i class="fa fa-cow me-2"></i> Livestock</a>
  <a href="view-pesticides.php"><i class="fa fa-bug me-2"></i> Pesticides</a>
  <a href="view-activities.php"><i class="fa fa-tractor me-2"></i> Activities</a>
  <div class="dropdown">
    <a href="#" class="dropdown-toggle px-3 d-block" data-bs-toggle="dropdown"><i class="fa fa-heartbeat me-2"></i> Mortality Rate</a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="birth-rate.php">Birth Rate</a></li>
      <li><a class="dropdown-item" href="death-rate.php">Death Rate</a></li>
    </ul>
  </div>
  <a href="eggs-production.php"><i class="fa fa-egg me-2"></i> Eggs Production</a>
  <a href="sales.php" class="bg-success"><i class="fa fa-cart-plus me-2"></i> Sales</a>
  <a href="view-sales.php"><i class="fa fa-file-invoice-dollar me-2"></i> View Sales</a>
  <a href="generate-report.php"><i class="fa fa-file-alt me-2"></i> Generate Report</a>
  <a href="request-item.php"><i class="fa fa-box-open me-2"></i> Request Item</a>
  <a href="view-requests.php"><i class="fa fa-eye me-2"></i> View Requests</a>
</div>

<div class="overlay" id="sidebarOverlay"></div>

<div class="content">

<div class="topbar">
  <button class="btn btn-success d-lg-none" id="toggleSidebar"><i class="fa fa-bars"></i></button>
  <div class="d-flex align-items-center">
    <div class="dropdown me-3">
      <a href="#" class="text-dark text-decoration-none position-relative" data-bs-toggle="dropdown">
        <i class="fa fa-bell fs-5"></i>
        <?php if($notificationCount>0): ?>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?= $notificationCount ?></span>
        <?php endif; ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php if($notificationCount==0): ?>
        <li><span class="dropdown-item text-muted">No new notifications</span></li>
        <?php else: while($notif=$notifications->fetch_assoc()): ?>
        <li><a class="dropdown-item" href="<?= $notif['link'] ?>"><?= $notif['message'] ?></a></li>
        <?php endwhile; endif; ?>
      </ul>
    </div>
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
        <img src="../uploads/<?= $admin['profile_picture'] ?>" class="profile-pic me-2">
        <?= htmlspecialchars($admin['username']) ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="profile.php">Manage Profile</a></li>
        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</div>

<h3 class="fw-bold mb-4">Stock & Sales Management</h3>
<?php if (isset($msg)) echo $msg; ?>

<!-- Add Item -->
<div class="card mb-4 shadow-sm">
  <div class="card-header bg-success text-white fw-bold">Add Item Stock & Price</div>
  <div class="card-body">
    <form method="POST">
      <div class="row g-3">
        <div class="col-md-4">
          <select name="item_name" class="form-select" required>
            <option value="">-- Select Item --</option>
            <?php foreach ($availableItems as $item) {
              echo "<option value='$item'>$item</option>";
            } ?>
          </select>
        </div>
        <div class="col-md-3">
          <input type="number" name="price" class="form-control" placeholder="Price (₦)" required>
        </div>
        <div class="col-md-3">
          <input type="number" name="stock" class="form-control" placeholder="Stock Quantity" required>
        </div>
        <div class="col-md-2 d-grid">
          <button type="submit" name="add_item" class="btn btn-primary">Add/Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Record Sale -->
<div class="card mb-4 shadow-sm">
  <div class="card-header bg-success text-white fw-bold">Record Sale</div>
  <div class="card-body">
    <form method="POST">
      <div id="sale-items">
        <div class="row g-3 mb-2">
          <div class="col-md-5">
            <select name="sale_item[]" class="form-select" required>
              <option value="">-- Select Item --</option>
              <?php
              $result = $conn->query("SELECT * FROM items ORDER BY item_name ASC");
              while($item = $result->fetch_assoc()) {
                echo "<option value='{$item['item_name']}'>{$item['item_name']} (₦".number_format($item['price'])." | Stock: {$item['stock']})</option>";
              } ?>
            </select>
          </div>
          <div class="col-md-3">
            <input type="number" name="quantity[]" class="form-control" placeholder="Quantity" required>
          </div>
          <div class="col-md-2 d-grid">
            <button type="button" class="btn btn-danger remove-item">Remove</button>
          </div>
        </div>
      </div>
      <button type="button" id="addMore" class="btn btn-secondary btn-sm">+ Add Another Item</button>
      <button type="submit" name="make_sale" class="btn btn-success mt-2">Sell All</button>
    </form>
  </div>
</div>

<!-- Stock Table -->
<div class="card shadow-sm">
  <div class="card-header bg-dark text-white fw-bold">Current Stock Overview</div>
  <div class="card-body p-0">
    <table class="table table-bordered mb-0">
      <thead class="table-light">
        <tr><th>#</th><th>Item</th><th>Price (₦)</th><th>Stock</th></tr>
      </thead>
      <tbody>
      <?php
      $sn=1;
      while ($item = $stockList->fetch_assoc()) {
        echo "<tr>
          <td>$sn</td>
          <td>{$item['item_name']}</td>
          <td>₦".number_format($item['price'])."</td>
          <td>{$item['stock']}</td>
        </tr>";
        $sn++;
      }
      ?>
      </tbody>
    </table>
  </div>
</div>


</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const sidebar=document.getElementById('sidebarMenu');
const overlay=document.getElementById('sidebarOverlay');
document.getElementById('toggleSidebar').onclick=()=>{sidebar.classList.toggle('show');overlay.classList.toggle('active');}
overlay.onclick=()=>{sidebar.classList.remove('show');overlay.classList.remove('active');}
</script>
</body>
</html>
