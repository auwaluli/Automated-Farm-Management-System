<?php
include '../includes/auth.php';
include '../includes/config.php';

// Fetch admin profile
$username = $_SESSION['admin_username'];
$resultAdmin = $conn->query("SELECT * FROM admins WHERE username='$username'");
$admin = $resultAdmin ? $resultAdmin->fetch_assoc() : ['profile_picture' => 'default.png', 'username' => 'Admin'];

// Fetch unread notifications
$notifications = $conn->query("SELECT * FROM notifications WHERE is_read=0 ORDER BY created_at DESC");
$notificationCount = $notifications->num_rows;

// Fetch requests
$requests = $conn->query("SELECT * FROM requests ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AFMIS | View Requests</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Nunito', sans-serif;
      margin: 0;
      padding: 0;
      overflow-x: hidden;
    }
    .sidebar {
      width: 230px;
      background: #198754;
      color: #fff;
      position: fixed;
      top: 0;
      bottom: 0;
      padding: 20px 0;
      overflow-y: auto;
      z-index: 1000;
    }
    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      font-weight: 600;
    }
    .sidebar a:hover, .sidebar .dropdown-menu a:hover {
      background: #157347;
    }
    .sidebar .dropdown-menu {
      background: #198754;
    }
    .sidebar .dropdown-menu a {
      color: #fff;
    }
    .topbar {
      position: fixed;
      left: 230px;
      right: 0;
      top: 0;
      background: #f8f9fa;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      z-index: 999;
      border-bottom: 1px solid #ddd;
    }
    .profile-pic {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      object-fit: cover;
    }
    .content {
      margin-left: 230px;
      padding: 80px 20px 20px;
    }
    .table-responsive {
      overflow-x: auto;
    }
    .table {
      width: 100%;
      min-width: 1200px;
    }
    footer {
      text-align: center;
      padding: 20px 0;
      color: #777;
      margin-top: 30px;
      border-top: 1px solid #ddd;
    }
    @media (max-width: 991.98px) {
      .sidebar {
        left: -250px;
      }
      .sidebar.show {
        left: 0;
      }
      .topbar {
        left: 0;
      }
      .content {
        margin-left: 0;
        padding-top: 70px;
      }
    }
  </style>
</head>
<body>

<div class="sidebar" id="sidebarMenu">
  <h4 class="text-center">🌿 AFMIS</h4>
  <a href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
  <a href="view-crops.php"><i class="fa fa-seedling me-2"></i> Crops</a>
  <a href="manage-livestock.php"><i class="fa fa-cow me-2"></i> Livestock</a>
  <a href="view-pesticides.php"><i class="fa fa-bug me-2"></i> Pesticides</a>
  <a href="view-activities.php"><i class="fa fa-tractor me-2"></i> Activities</a>
  <div class="dropdown">
    <a href="#" class="dropdown-toggle px-3 d-block" data-bs-toggle="dropdown"><i class="fa fa-heartbeat me-2"></i> Mortality Rate</a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="birth-rate.php">Birth Rate</a></li>
      <li><a class="dropdown-item" href="death-rate.php">Death Rate</a></li>
    </ul>
  </div>
  <a href="eggs-production.php"><i class="fa fa-egg me-2"></i> Eggs Production</a>
  <a href="sales.php"><i class="fa fa-cart-plus me-2"></i> Sales</a>
  <a href="view-sales.php"><i class="fa fa-file-invoice-dollar me-2"></i> View Sales</a>
  <a href="generate-report.php"><i class="fa fa-file-alt me-2"></i> Generate Report</a>
  <a href="request-item.php"><i class="fa fa-box-open me-2"></i> Request Item</a>
  <a href="view-requests.php" class="bg-success"><i class="fa fa-list me-2"></i> View Requests</a>
</div>

<div class="topbar">
  <button class="btn btn-success d-lg-none" id="toggleSidebar"><i class="fa fa-bars"></i></button>
  <div class="d-flex align-items-center">
    <div class="dropdown me-3">
      <a href="#" class="text-dark text-decoration-none position-relative" data-bs-toggle="dropdown">
        <i class="fa fa-bell fs-5"></i>
        <?php if($notificationCount>0): ?>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?= $notificationCount ?></span>
        <?php endif; ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php if($notificationCount==0): ?>
          <li><span class="dropdown-item text-muted">No new notifications</span></li>
        <?php else: while($notif=$notifications->fetch_assoc()): ?>
          <li><a class="dropdown-item" href="<?= htmlspecialchars($notif['link']) ?>"><?= htmlspecialchars($notif['message']) ?></a></li>
        <?php endwhile; endif; ?>
      </ul>
    </div>
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
        <img src="../uploads/<?= htmlspecialchars($admin['profile_picture']) ?>" class="profile-pic me-2">
        <?= htmlspecialchars($admin['username']) ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="profile.php">Manage Profile</a></li>
        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</div>

<div class="content">
  <h3 class="fw-bold mb-4">All Item Requests</h3>

  <div class="table-responsive">
    <table class="table table-bordered table-striped table-hover">
      <thead class="table-success">
        <tr>
          <th>#</th>
          <th>Item</th>
          <th>Description</th>
          <th>Quantity</th>
          <th>Requested By</th>
          <th>Date Requested</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if($requests->num_rows>0): $i=1;
        while($row=$requests->fetch_assoc()): ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= htmlspecialchars($row['item_name']) ?></td>
          <td><?= nl2br(htmlspecialchars($row['description'])) ?></td>
          <td><?= (int)$row['quantity'] ?></td>
          <td><?= htmlspecialchars($row['admin_username']) ?></td>
          <td><?= date('d M Y h:i A', strtotime($row['created_at'])) ?></td>
          <td>
            <a href="edit-request.php?id=<?= (int)$row['id'] ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
            <a href="delete-request.php?id=<?= (int)$row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this request?')"><i class="fa fa-trash"></i></a>
          </td>
        </tr>
        <?php endwhile;
        else: ?>
        <tr><td colspan="7" class="text-center text-muted">No requests found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const sidebar = document.getElementById('sidebarMenu');
  const toggleBtn = document.getElementById('toggleSidebar');
  toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('show');
  });
</script>
</body>
</html>
